import subprocess
import tempfile
import os
import sys
import json
from pathlib import Path

def run_generated_test(code: str, save_to: str = 'generated_test.py'):
    # save file
    Path(save_to).write_text(code, encoding='utf-8')
    # run pytest on the saved file or run as script
    try:
        # try running via python
        proc = subprocess.run([sys.executable, save_to], capture_output=True, text=True, timeout=60)
        return {'returncode': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr}
    except Exception as e:
        return {'error': str(e)}

if __name__ == '__main__':
    print('This module exposes run_generated_test(code)')
