import os
import openai

OPENAI_KEY = os.getenv('OPENAI_API_KEY')
if OPENAI_KEY is None:
    raise RuntimeError('Please set OPENAI_API_KEY environment variable')
openai.api_key = OPENAI_KEY

# Simple wrapper: sends a prompt to OpenAI to translate NL test instruction into Playwright Python code.
def nl_to_playwright_code(nl_instruction: str) -> str:
    prompt = f"""You are a test-generation assistant.
Convert the user's natural-language test instructions into a Playwright Python script (sync API).
Keep the result as a single plain python script only — do NOT add additional explanation.

Instruction:
{nl_instruction}

Include necessary imports and a `run_test()` function and an `if __name__ == '__main__':` block.
"""
    resp = openai.ChatCompletion.create(
        model='gpt-4o-mini', # replace with a model you have access to, or 'gpt-4'/'gpt-3.5-turbo'
        messages=[{'role':'user','content':prompt}],
        temperature=0.0,
        max_tokens=800
    )
    code = resp['choices'][0]['message']['content']
    return code
