# AI E2E Testing Agent (Playwright + OpenAI + Streamlit)

**What this repo contains**
- `streamlit_app.py` — Frontend UI (Streamlit, dark theme) to enter natural-language test instructions.
- `agent.py` — Simple agent that uses OpenAI to convert NL instructions to Playwright Python test code (template).
- `playwright_runner.py` — Executes generated Playwright tests and collects a basic report.
- `demo_site/index.html` — Small static demo website for testing.
- `requirements.txt` — Python dependencies.
- `example_generated_test.py` — Example test that Playwright can run.

**Important**
- This is a local prototype. You must install Playwright browsers separately: `playwright install`.
- Provide your OpenAI API key in the environment variable `OPENAI_API_KEY` or in `.env` if you prefer.

**Quick start**
1. Create a Python venv: `python -m venv .venv && source .venv/bin/activate` (Windows: `.venv\Scripts\activate`)
2. Install: `pip install -r requirements.txt`
3. Install Playwright browsers: `playwright install`
4. Run the demo site (optional): `python -m http.server --directory demo_site 8000`
5. Run Streamlit UI: `streamlit run streamlit_app.py`

**Notes**
- The `agent.py` contains an example OpenAI call (uses `openai` package). The prompt is a template — adjust for your needs.
- This project intentionally keeps code readable and modular so you can extend it (LangGraph/advanced parsing, reporting UI).
