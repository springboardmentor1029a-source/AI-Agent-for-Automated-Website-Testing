#!/usr/bin/env bash
echo "1) Install dependencies: pip install -r requirements.txt"
echo "2) Install Playwright browsers: playwright install"
echo "3) Run demo site: python -m http.server --directory demo_site 8000"
echo "4) Run Streamlit: streamlit run streamlit_app.py"
