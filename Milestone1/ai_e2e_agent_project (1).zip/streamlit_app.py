import streamlit as st
from agent import nl_to_playwright_code
from playwright_runner import run_generated_test
import os, textwrap

st.set_page_config(page_title='AI Test Agent', layout='wide', initial_sidebar_state='expanded')
st.markdown("""<style>
/* Dark theme adjustments */
.stApp { background: linear-gradient(180deg,#06121a,#071226); color:#cbd5e1; }
.css-1v3fvcr { background: rgba(255,255,255,0.03); } /* card */
.stButton>button { background: #0ea5a4; color:#022; border-radius:12px; padding:8px 12px; }
.stTextInput>div>div>input { background:#081021; color:#e6eef8; }
</style>"", unsafe_allow_html=True)

st.title('AI Agent — E2E Website Test Generator')
st.write('Enter natural language test instructions and the agent will generate and run a Playwright script.')

with st.expander('Example'):
    st.write('Login to demo site at http://localhost:8000, enter user@example.com and password123, click login, expect to be on dashboard.')

instruction = st.text_area('Natural language test instruction', height=160, value='Login to demo site at http://localhost:8000, use email user@example.com and password password123, click login, expect to see Dashboard page.')

col1, col2 = st.columns([2,1])
with col2:
    model = st.text_input('OpenAI model name', value='gpt-4o-mini')
    run_now = st.button('Generate & Run Test')

if run_now:
    if instruction.strip() == '':
        st.error('Please provide an instruction.')
    else:
        st.info('Sending to OpenAI to generate Playwright code (template).')
        try:
            code = nl_to_playwright_code(instruction)
        except Exception as e:
            st.error(f'OpenAI call failed: {e}')
            code = None
        if code:
            st.subheader('Generated Test Code')
            st.code(code, language='python')
            st.info('Executing generated code in a sandboxed subprocess (local).')
            result = run_generated_test(code, save_to='generated_test.py')
            st.subheader('Execution Report')
            st.json(result)
            if result.get('stdout'):
                st.text('Stdout:')
                st.text(result['stdout'][:10000])
            if result.get('stderr'):
                st.text('Stderr:')
                st.text(result['stderr'][:10000])
